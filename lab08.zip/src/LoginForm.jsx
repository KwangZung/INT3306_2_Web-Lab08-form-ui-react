import React, { useState, useEffect, useCallback, useMemo, useRef } from "react";

function RegisterForm() {
  // 1️⃣ useState — lưu thông tin form
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");

  // 2️⃣ useRef — trỏ đến ô nhập đầu tiên để focus
  const usernameRef = useRef(null);

  useEffect(() => {
    usernameRef.current.focus(); // Tự động focus vào ô username khi form load
  }, []);

  // 3️⃣ useCallback — tránh tạo lại hàm mỗi lần render
  const handleSubmit = useCallback((e) => {
    e.preventDefault();
    if (password !== confirmPassword) {
      setMessage("Passwords do not match");
      return;
    }
    setMessage(`Welcome, ${username}!`);
  }, [password, confirmPassword, username]);

  // 4️⃣ useMemo — tính toán giá trị nặng hoặc kiểm tra hợp lệ
  const isFormValid = useMemo(() => {
    return username && email.includes("@") && password.length >= 6 && password === confirmPassword;
  }, [username, email, password, confirmPassword]);

  // 5️⃣ useEffect — hiển thị message khi có thay đổi
  useEffect(() => {
    if (message) console.log("Message:", message);
  }, [message]);

  return (
    <div style={{ maxWidth: "350px", margin: "40px auto", padding: "20px", border: "1px solid #ccc", borderRadius: "10px" }}>
      <h2>Register</h2>
      <form onSubmit={handleSubmit}>
        <input
          ref={usernameRef}
          type="text"
          placeholder="Username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          style={{ display: "block", width: "100%", marginBottom: "10px" }}
        />

        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          style={{ display: "block", width: "100%", marginBottom: "10px" }}
        />

        <input
          type="password"
          placeholder="Password (min 6 chars)"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          style={{ display: "block", width: "100%", marginBottom: "10px" }}
        />

        <input
          type="password"
          placeholder="Confirm Password"
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
          style={{ display: "block", width: "100%", marginBottom: "10px" }}
        />

        <button
          type="submit"
          disabled={!isFormValid}
          style={{
            width: "100%",
            padding: "10px",
            background: isFormValid ? "#4CAF50" : "#ccc",
            color: "#fff",
            border: "none",
            borderRadius: "5px",
            cursor: isFormValid ? "pointer" : "not-allowed",
          }}
        >
          Register
        </button>
      </form>

      {message && <p style={{ marginTop: "15px", color: message.includes("match") ? "red" : "green" }}>{message}</p>}
    </div>
  );
}

export default RegisterForm;
